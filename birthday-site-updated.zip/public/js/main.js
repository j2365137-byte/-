// Simple confetti/hearts animation for fun (no external libs)
(function(){
  const btn = document.getElementById('confettiBtn');
  if (!btn) return;
  btn.addEventListener('click', () => {
    const count = 80;
    for (let i = 0; i < count; i++) {
      setTimeout(spawnHeart, i * 20);
    }
  });

  function spawnHeart() {
    const heart = document.createElement('div');
    heart.textContent = ['💖','💝','💓','💗','💞','💕'][Math.floor(Math.random()*6)];
    heart.style.position = 'fixed';
    heart.style.left = Math.random()*100 + 'vw';
    heart.style.top = '-20px';
    heart.style.fontSize = (16 + Math.random()*28) + 'px';
    heart.style.transition = 'transform 3s linear, opacity 3s linear';
    heart.style.zIndex = 9999;
    document.body.appendChild(heart);
    const endX = (Math.random()*2-1)*120; // drift
    requestAnimationFrame(() => {
      heart.style.transform = `translate(${endX}vw, 110vh) rotate(${(Math.random()*2-1)*180}deg)`;
      heart.style.opacity = 0;
    });
    setTimeout(()=>heart.remove(), 3200);
  }
})();
