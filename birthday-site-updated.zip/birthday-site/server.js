const fs = require('fs');
const path = require('path');
const express = require('express');
const basicAuth = require('express-basic-auth');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const dayjs = require('dayjs');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const SITE_TITLE = process.env.SITE_TITLE || '生日快乐 🎂';
const GREETING_NAME = process.env.GREETING_NAME || '亲爱的';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'changeme';

// Ensure data/uploads folders exist
const dataDir = path.join(__dirname, 'data');
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

// Database
const dbPath = path.join(dataDir, 'app.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS moods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    mood TEXT CHECK(mood IN ('happy','sad')) NOT NULL,
    text TEXT,
    created_at TEXT NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    caption TEXT,
    filename TEXT NOT NULL,
    created_at TEXT NOT NULL
  )`);
});

// View engine & static files
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(uploadDir));

// Simple basic auth for admin-only routes
const adminAuth = basicAuth({
  users: { [ADMIN_USER]: ADMIN_PASSWORD },
  challenge: true,
  realm: 'Birthday Admin Area'
});

// Multer setup for uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1e6) + ext);
  }
});

const fileFilter = (req, file, cb) => {
  const allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
  if (allowed.includes(file.mimetype)) cb(null, true);
  else cb(new Error('仅支持 JPG/PNG/GIF/WebP 图片'));
};

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter
});

// Helpers
const fmtDate = (d) => {
  if (!d) return '';
  try {
    return dayjs(d).format('YYYY年MM月DD日');
  } catch {
    return d;
  }
};

// Routes
app.get('/', (req, res) => {
  res.render('index', { SITE_TITLE, GREETING_NAME });
});

app.get('/moods', (req, res) => {
  db.all('SELECT * FROM moods ORDER BY datetime(created_at) DESC', [], (err, rows) => {
    if (err) return res.status(500).send('数据库错误');
    res.render('moods', { SITE_TITLE, rows, fmtDate });
  });
});

app.get('/photos', (req, res) => {
  db.all('SELECT * FROM photos ORDER BY datetime(created_at) DESC', [], (err, rows) => {
    if (err) return res.status(500).send('数据库错误');
    res.render('photos', { SITE_TITLE, rows, fmtDate });
  });
});

app.get('/admin', adminAuth, (req, res) => {
  res.render('admin', { SITE_TITLE });
});

app.post('/moods', adminAuth, (req, res) => {
  const { date, mood, text } = req.body;
  const created_at = new Date().toISOString();
  if (!mood || !['happy', 'sad'].includes(mood)) {
    return res.status(400).send('参数错误');
  }
  db.run('INSERT INTO moods (date, mood, text, created_at) VALUES (?,?,?,?)',
    [date || null, mood, text || null, created_at],
    function (err) {
      if (err) return res.status(500).send('数据库错误');
      res.redirect('/moods');
    });
});

app.post('/photos', adminAuth, upload.single('photo'), (req, res) => {
  if (!req.file) return res.status(400).send('请上传图片');
  const { date, caption } = req.body;
  const created_at = new Date().toISOString();
  db.run('INSERT INTO photos (date, caption, filename, created_at) VALUES (?,?,?,?)',
    [date || null, caption || null, req.file.filename, created_at],
    function (err) {
      if (err) return res.status(500).send('数据库错误');
      res.redirect('/photos');
    });
});

// Basic 404
app.use((req, res) => {
  res.status(404).send('页面不存在 😿');
});

app.listen(PORT, () => {
  console.log(`Server running at http://0.0.0.0:${PORT}`);
});
