# 生日快乐网站 🎂

一个简单可爱的站点，用来对 TA 说“生日快乐”，并记录**开心/不开心**和**吃饭照片**。  
技术栈：Node.js + Express + EJS + SQLite，支持 Docker 一键部署。

## 快速开始（推荐：Docker）

1. 下载并解压本项目。
2. 复制环境变量文件：
   ```bash
   cp .env.example .env
   ```
3. 编辑 `.env`，至少修改 `ADMIN_PASSWORD` 为强密码。
4. 运行：
   ```bash
   docker compose up -d --build
   ```
5. 打开浏览器访问：
   - 主页（生日祝福）：`http://<你的服务器IP>:3000/`
   - 心情列表：`/moods`
   - 照片墙：`/photos`
   - 管理页（需要密码）：`/admin`

## 无 Docker 运行

确保服务器已安装 Node.js 18+：
```bash
npm install
npm start
```

## 功能说明

- 主页：祝福页（带小心心烟花按钮）
- 心情页：开心/不开心列表
- 照片页：吃饭照片网格
- 管理页：添加心情、上传照片（基本认证保护）

## 数据存储

- SQLite 数据库：`data/app.db`
- 图片上传目录：`uploads/`（已做类型和大小限制）

## 安全提示

- 务必修改 `.env` 里的 `ADMIN_PASSWORD`。
- 若公网访问，建议使用 Nginx/Traefik 配置 HTTPS（反代到本容器的 3000 端口）。

## 自定义

- 修改 `.env` 里的 `SITE_TITLE`、`GREETING_NAME`。
- 调整样式：`public/css/styles.css`。
- 页面模板：`views/` 目录。
